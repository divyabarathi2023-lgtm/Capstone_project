import re
from datetime import datetime

from flask import Blueprint, flash, g, redirect, render_template, request, session, url_for
from werkzeug.security import check_password_hash, generate_password_hash

import db
from auth_utils import home_for

bp = Blueprint("auth", __name__)
EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


@bp.route("/register", methods=["GET", "POST"])
def register():
    if g.get("user"):
        return redirect(home_for(g.user["role"]))
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip().lower()
        phone = request.form.get("phone", "").strip()[:20]
        pwd = request.form.get("password", "")
        if len(name) < 2 or len(name) > 100:
            flash("Please enter your name.", "danger")
        elif not EMAIL_RE.match(email) or len(email) > 150:
            flash("Please enter a valid email.", "danger")
        elif len(pwd) < 6:
            flash("Password must be at least 6 characters.", "danger")
        elif db.query("SELECT id FROM users WHERE email=%s", (email,), one=True):
            flash("This email is already registered.", "danger")
        else:
            db.execute(
                "INSERT INTO users (name,email,phone,password_hash,role,created_at) VALUES (%s,%s,%s,%s,'citizen',%s)",
                (name, email, phone or None, generate_password_hash(pwd), datetime.now()))
            flash("Registration successful. Please login.", "success")
            return redirect(url_for("auth.login"))
    return render_template("register.html")


@bp.route("/login", methods=["GET", "POST"])
def login():
    if g.get("user"):
        return redirect(home_for(g.user["role"]))
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        pwd = request.form.get("password", "")
        u = db.query("SELECT * FROM users WHERE email=%s", (email,), one=True)
        if u and check_password_hash(u["password_hash"], pwd):
            session.clear()
            session["user_id"] = u["id"]
            return redirect(home_for(u["role"]))
        flash("Invalid email or password.", "danger")
    return render_template("login.html")


@bp.route("/logout")
def logout():
    session.clear()
    flash("Logged out.", "info")
    return redirect(url_for("auth.login"))
