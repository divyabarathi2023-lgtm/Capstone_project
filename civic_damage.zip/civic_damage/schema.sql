CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(150) NOT NULL UNIQUE,
  phone VARCHAR(20) NULL,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('citizen','admin','worker') NOT NULL DEFAULT 'citizen',
  created_at DATETIME NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS complaints (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  title VARCHAR(200) NOT NULL,
  category VARCHAR(60) NOT NULL,
  location_type VARCHAR(60) NOT NULL,
  latitude DOUBLE NOT NULL,
  longitude DOUBLE NOT NULL,
  image_path VARCHAR(255) NOT NULL,
  phash CHAR(16) NOT NULL,
  color_hist MEDIUMTEXT NOT NULL,
  status ENUM('Submitted','Assigned','In Progress','Completed','Resolved') NOT NULL DEFAULT 'Submitted',
  ai_status ENUM('pending','done','failed','skipped') NOT NULL DEFAULT 'pending',
  priority_score INT NOT NULL DEFAULT 0,
  priority_level VARCHAR(20) NOT NULL DEFAULT 'Low',
  primary_id INT NULL,
  report_count INT NOT NULL DEFAULT 1,
  affected_citizens INT NOT NULL DEFAULT 1,
  assigned_worker_id INT NULL,
  assigned_at DATETIME NULL,
  admin_note TEXT NULL,
  completion_photo VARCHAR(255) NULL,
  worker_note TEXT NULL,
  completed_at DATETIME NULL,
  resolved_at DATETIME NULL,
  created_at DATETIME NOT NULL,
  INDEX idx_geo (category, latitude, longitude),
  INDEX idx_primary (primary_id),
  INDEX idx_user (user_id),
  INDEX idx_worker (assigned_worker_id),
  FOREIGN KEY (user_id) REFERENCES users(id),
  FOREIGN KEY (assigned_worker_id) REFERENCES users(id),
  FOREIGN KEY (primary_id) REFERENCES complaints(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS ai_analysis (
  id INT AUTO_INCREMENT PRIMARY KEY,
  complaint_id INT NOT NULL,
  damage_type VARCHAR(120) NOT NULL,
  severity ENUM('Low','Medium','High','Critical') NOT NULL,
  risk ENUM('Low','Medium','High','Critical') NOT NULL,
  confidence DOUBLE NOT NULL,
  description TEXT NOT NULL,
  repair_action TEXT NOT NULL,
  raw_json MEDIUMTEXT NULL,
  created_at DATETIME NOT NULL,
  FOREIGN KEY (complaint_id) REFERENCES complaints(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS notifications (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  complaint_id INT NULL,
  message VARCHAR(500) NOT NULL,
  is_read TINYINT(1) NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL,
  INDEX idx_notif_user (user_id, is_read),
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (complaint_id) REFERENCES complaints(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
