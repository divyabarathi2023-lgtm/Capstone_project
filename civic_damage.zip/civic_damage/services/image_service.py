import io
import json
import os
import uuid

import cv2
import numpy as np
from PIL import Image

ALLOWED_EXT = {"jpg", "jpeg", "png", "webp"}
FORMAT_INFO = {"JPEG": ("jpg", "image/jpeg"), "PNG": ("png", "image/png"), "WEBP": ("webp", "image/webp")}


class ImageError(ValueError):
    """User-facing image validation error."""


def validate_and_save(file_storage, upload_dir, max_bytes, prefix="img"):
    """Validate (ext, real image, size) and save. Returns (filename, cv2_image, mime)."""
    if not file_storage or not file_storage.filename:
        raise ImageError("Please select a photo.")
    name = file_storage.filename
    ext = name.rsplit(".", 1)[-1].lower() if "." in name else ""
    if ext not in ALLOWED_EXT:
        raise ImageError("Only JPG, PNG or WEBP images are allowed.")

    data = file_storage.read()
    if not data:
        raise ImageError("The uploaded file is empty.")
    if len(data) > max_bytes:
        raise ImageError("Image is too large. Maximum size is 8 MB.")

    try:
        img = Image.open(io.BytesIO(data))
        fmt = img.format
        img.verify()
    except Exception:
        raise ImageError("The file is not a valid image.")
    if fmt not in FORMAT_INFO:
        raise ImageError("Only JPG, PNG or WEBP images are allowed.")

    cv_img = cv2.imdecode(np.frombuffer(data, np.uint8), cv2.IMREAD_COLOR)
    if cv_img is None:
        raise ImageError("The image could not be read. Try another photo.")

    ext_out, mime = FORMAT_INFO[fmt]
    filename = f"{prefix}_{uuid.uuid4().hex}.{ext_out}"
    os.makedirs(upload_dir, exist_ok=True)
    with open(os.path.join(upload_dir, filename), "wb") as f:
        f.write(data)
    return filename, cv_img, mime


def mime_from_filename(filename):
    ext = filename.rsplit(".", 1)[-1].lower()
    return {"jpg": "image/jpeg", "jpeg": "image/jpeg", "png": "image/png", "webp": "image/webp"}.get(ext, "image/jpeg")


def fingerprint(cv_img):
    """Returns (perceptual_hash_hex_64bit, colour_histogram_list)."""
    gray = cv2.cvtColor(cv_img, cv2.COLOR_BGR2GRAY)
    small = cv2.resize(gray, (32, 32), interpolation=cv2.INTER_AREA).astype(np.float32)
    low = cv2.dct(small)[:8, :8].flatten()
    med = np.median(low[1:])
    bits = "".join("1" if v > med else "0" for v in low)
    phash = f"{int(bits, 2):016x}"

    hsv = cv2.cvtColor(cv_img, cv2.COLOR_BGR2HSV)
    hist = cv2.calcHist([hsv], [0, 1, 2], None, [8, 4, 4], [0, 180, 0, 256, 0, 256]).flatten()
    total = float(hist.sum())
    if total > 0:
        hist = hist / total
    return phash, [round(float(v), 6) for v in hist]


def similarity(phash_a, hist_a, phash_b, hist_b):
    """0..1 : 50% perceptual-hash similarity + 50% colour-histogram correlation."""
    ham = bin(int(phash_a, 16) ^ int(phash_b, 16)).count("1")
    p_sim = 1.0 - ham / 64.0
    a = np.array(json.loads(hist_a) if isinstance(hist_a, str) else hist_a, dtype=np.float32)
    b = np.array(json.loads(hist_b) if isinstance(hist_b, str) else hist_b, dtype=np.float32)
    if a.shape != b.shape or a.size == 0:
        h_sim = 0.0
    else:
        h_sim = float(cv2.compareHist(a.reshape(-1, 1), b.reshape(-1, 1), cv2.HISTCMP_CORREL))
        h_sim = min(1.0, max(0.0, h_sim))
    return 0.5 * p_sim + 0.5 * h_sim
