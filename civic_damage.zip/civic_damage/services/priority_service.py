from datetime import datetime

RANK = {"low": 0.25, "medium": 0.5, "high": 0.75, "critical": 1.0}
LOCATION_WEIGHT = {
    "Hospital / School Zone": 1.0,
    "Main Road": 0.9,
    "Market / Commercial Area": 0.8,
    "Residential Street": 0.6,
    "Public Park": 0.5,
    "Other": 0.4,
}
# weights (total 100)
W_SEVERITY, W_RISK, W_AFFECTED, W_LOCATION, W_WAIT = 30, 25, 20, 15, 10


def level_rank(level):
    return RANK.get((level or "").lower(), 0.5)


def level_name(score):
    if score >= 80:
        return "Critical"
    if score >= 60:
        return "High"
    if score >= 40:
        return "Medium"
    return "Low"


def compute(severity, risk, affected, location_type, created_at, now=None):
    """Returns (score 0-100, level). severity/risk None -> medium assumed (AI illa na)."""
    now = now or datetime.now()
    sev = level_rank(severity) if severity else 0.5
    rsk = level_rank(risk) if risk else 0.5
    aff = min(max(int(affected or 1), 1), 10) / 10.0
    loc = LOCATION_WEIGHT.get(location_type, 0.4)
    days = max((now - created_at).days, 0) if created_at else 0
    wait = min(days, 14) / 14.0
    score = sev * W_SEVERITY + rsk * W_RISK + aff * W_AFFECTED + loc * W_LOCATION + wait * W_WAIT
    score = int(round(min(score, 100)))
    return score, level_name(score)
