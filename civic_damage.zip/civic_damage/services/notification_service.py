from datetime import datetime
import db


def notify(user_id, complaint_id, message):
    db.execute(
        "INSERT INTO notifications (user_id, complaint_id, message, created_at) VALUES (%s,%s,%s,%s)",
        (user_id, complaint_id, message[:500], datetime.now()),
    )


def notify_group(primary_id, message):
    """Primary complaint + adhoda duplicate reports ellaa citizens-kum notification."""
    rows = db.query("SELECT id, user_id FROM complaints WHERE id=%s OR primary_id=%s", (primary_id, primary_id))
    seen = set()
    for r in rows:
        if r["user_id"] in seen:
            continue
        seen.add(r["user_id"])
        notify(r["user_id"], r["id"], message)
