import math
import db
from services import image_service


def haversine_m(lat1, lon1, lat2, lon2):
    r = 6371000.0
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp, dl = p2 - p1, math.radians(lon2 - lon1)
    a = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * r * math.asin(math.sqrt(a))


def find_primary(c, radius_m, threshold):
    """Same category + within radius + image similarity >= threshold. Returns (primary_id, sim, dist) or None."""
    lat, lng = c["latitude"], c["longitude"]
    dlat = radius_m / 111320.0 * 1.3
    dlng = dlat / max(math.cos(math.radians(lat)), 0.01)
    rows = db.query(
        "SELECT id, latitude, longitude, phash, color_hist FROM complaints "
        "WHERE primary_id IS NULL AND id<>%s AND category=%s AND status<>'Resolved' "
        "AND latitude BETWEEN %s AND %s AND longitude BETWEEN %s AND %s",
        (c["id"], c["category"], lat - dlat, lat + dlat, lng - dlng, lng + dlng),
    )
    best = None
    for r in rows:
        dist = haversine_m(lat, lng, r["latitude"], r["longitude"])
        if dist > radius_m:
            continue
        sim = image_service.similarity(c["phash"], c["color_hist"], r["phash"], r["color_hist"])
        if sim >= threshold and (best is None or sim > best[1]):
            best = (r["id"], sim, dist)
    return best
