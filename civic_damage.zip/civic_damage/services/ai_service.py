"""
Nexus API integration.
Nexus documentation vandha apuram, ingha EDIT pannanum:
    1. config.py        -> NEXUS_API_KEY, NEXUS_API_URL, NEXUS_MODEL
    2. build_request()  -> doc-la solra header / body format-ku maathunga
    3. Response format vera maari irundhaalum _find_result() automatic-ah JSON-a thedum.
Key fill pannala na app crash aagaadhu - ai_status = 'skipped' nu save aagum.
"""
import base64
import json
import re

import requests

PROMPT = (
    "You are a civil-infrastructure inspector. Analyse this photo of public damage "
    "(road, footpath, drainage, streetlight, pipe, etc.). Reply with ONLY a JSON object with exactly "
    "these keys: damage_type (string), severity (one of Low, Medium, High, Critical), "
    "risk (public safety risk: one of Low, Medium, High, Critical), confidence (number 0 to 1), "
    "description (short string), repair_action (short string)."
)
REQUIRED = {"damage_type", "severity", "risk", "confidence", "description", "repair_action"}


def is_configured(cfg):
    key, url = cfg.get("NEXUS_API_KEY", ""), cfg.get("NEXUS_API_URL", "")
    return bool(key) and bool(url) and "PASTE_" not in key and "PASTE_" not in url


def build_request(cfg, image_b64, mime):
    """<<< Nexus doc padichu ingha format-a maathunga >>>"""
    headers = {"Authorization": f"Bearer {cfg['NEXUS_API_KEY']}", "Content-Type": "application/json"}
    payload = {"prompt": PROMPT, "image": image_b64, "image_mime_type": mime}
    if cfg.get("NEXUS_MODEL"):
        payload["model"] = cfg["NEXUS_MODEL"]
    return headers, payload


def _find_result(obj):
    """Response-kulla evlo deep-ah irundhaalum, required keys irukkura JSON object-a kandupidikkum."""
    if isinstance(obj, dict):
        if REQUIRED.issubset(obj.keys()):
            return obj
        for v in obj.values():
            r = _find_result(v)
            if r:
                return r
    elif isinstance(obj, list):
        for v in obj:
            r = _find_result(v)
            if r:
                return r
    elif isinstance(obj, str):
        s = re.sub(r"```(?:json)?", "", obj).strip()
        i, j = s.find("{"), s.rfind("}")
        if i != -1 and j > i:
            try:
                return _find_result(json.loads(s[i:j + 1]))
            except ValueError:
                return None
    return None


def _norm_level(v):
    if isinstance(v, (int, float)):
        x = float(v)
        if x <= 1:
            x *= 10
        return "Critical" if x >= 8 else "High" if x >= 6 else "Medium" if x >= 3 else "Low"
    s = str(v).strip().lower()
    for key, out in (("critical", "Critical"), ("severe", "Critical"), ("high", "High"),
                     ("medium", "Medium"), ("moderate", "Medium"), ("low", "Low"), ("minor", "Low")):
        if key in s:
            return out
    return None


def validate_result(raw):
    """Validate + normalise. Returns clean dict or raises ValueError."""
    sev, risk = _norm_level(raw["severity"]), _norm_level(raw["risk"])
    if sev is None or risk is None:
        raise ValueError("severity/risk value invalid")
    try:
        conf = float(str(raw["confidence"]).replace("%", ""))
    except ValueError:
        raise ValueError("confidence invalid")
    if conf > 1:
        conf /= 100.0
    conf = max(0.0, min(1.0, conf))
    damage = str(raw["damage_type"]).strip()[:120]
    desc, action = str(raw["description"]).strip(), str(raw["repair_action"]).strip()
    if not damage or not desc or not action:
        raise ValueError("empty text fields")
    return {"damage_type": damage, "severity": sev, "risk": risk, "confidence": conf,
            "description": desc, "repair_action": action}


def analyze(cfg, image_path, mime):
    """Returns (clean_result_or_None, status, message). status: done | skipped | failed."""
    if not is_configured(cfg):
        return None, "skipped", "Nexus API key/URL not configured"
    try:
        with open(image_path, "rb") as f:
            b64 = base64.b64encode(f.read()).decode("ascii")
        headers, payload = build_request(cfg, b64, mime)
        resp = requests.post(cfg["NEXUS_API_URL"], headers=headers, json=payload, timeout=cfg["NEXUS_TIMEOUT"])
        resp.raise_for_status()
        try:
            body = resp.json()
        except ValueError:
            body = resp.text
        raw = _find_result(body)
        if raw is None:
            return None, "failed", "Nexus response-la expected JSON fields illa"
        return validate_result(raw), "done", json.dumps(raw)
    except requests.RequestException as e:
        return None, "failed", f"Nexus request error: {e}"
    except (ValueError, KeyError, OSError) as e:
        return None, "failed", f"Nexus result invalid: {e}"
