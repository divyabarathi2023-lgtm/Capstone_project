import json
import os
from datetime import datetime

from flask import current_app

import db
from services import ai_service, duplicate_service, image_service, priority_service
from services.notification_service import notify

CATEGORIES = ["Pothole", "Road Crack", "Broken Footpath", "Drainage / Manhole Damage",
              "Streetlight Damage", "Water Pipe Leak", "Other"]
LOCATION_TYPES = list(priority_service.LOCATION_WEIGHT.keys())


def create_complaint(user, form, photo):
    """Full pipeline. Raises ValueError (user-facing message) on bad input."""
    cfg = current_app.config
    title = (form.get("title") or "").strip()
    category = form.get("category") or ""
    location_type = form.get("location_type") or ""
    if len(title) < 3 or len(title) > 200:
        raise ValueError("Title must be 3 to 200 characters.")
    if category not in CATEGORIES:
        raise ValueError("Please choose a valid category.")
    if location_type not in LOCATION_TYPES:
        raise ValueError("Please choose a valid location type.")
    try:
        lat, lng = float(form.get("latitude")), float(form.get("longitude"))
    except (TypeError, ValueError):
        raise ValueError("Location is required. Allow GPS in your browser or enter latitude/longitude.")
    if not (-90 <= lat <= 90 and -180 <= lng <= 180):
        raise ValueError("Latitude/longitude out of range.")

    # 1-2. validate image + fingerprint
    filename, cv_img, _mime = image_service.validate_and_save(
        photo, cfg["UPLOAD_FOLDER"], cfg["MAX_IMAGE_BYTES"], "complaint")
    phash, hist = image_service.fingerprint(cv_img)

    # 3. save complaint
    cid = db.execute(
        "INSERT INTO complaints (user_id,title,category,location_type,latitude,longitude,image_path,"
        "phash,color_hist,status,ai_status,created_at) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,'Submitted','pending',%s)",
        (user["id"], title, category, location_type, lat, lng, filename, phash, json.dumps(hist), datetime.now()),
    )

    # 4. AI analysis
    run_ai(cid)

    # 5-7. duplicate check, priority score, notification
    link_or_prioritise(cid)
    return cid


def run_ai(cid):
    cfg = current_app.config
    c = db.query("SELECT id, image_path FROM complaints WHERE id=%s", (cid,), one=True)
    path = os.path.join(cfg["UPLOAD_FOLDER"], c["image_path"])
    result, status, msg = ai_service.analyze(cfg, path, image_service.mime_from_filename(c["image_path"]))
    if status == "done":
        db.execute("DELETE FROM ai_analysis WHERE complaint_id=%s", (cid,))
        db.execute(
            "INSERT INTO ai_analysis (complaint_id,damage_type,severity,risk,confidence,description,"
            "repair_action,raw_json,created_at) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s)",
            (cid, result["damage_type"], result["severity"], result["risk"], result["confidence"],
             result["description"], result["repair_action"], msg, datetime.now()),
        )
    db.execute("UPDATE complaints SET ai_status=%s WHERE id=%s", (status, cid))
    return status, (msg if status != "done" else "")


def refresh_group_counts(pid):
    r = db.query("SELECT COUNT(*) AS n, COUNT(DISTINCT user_id) AS u FROM complaints WHERE id=%s OR primary_id=%s",
                 (pid, pid), one=True)
    db.execute("UPDATE complaints SET report_count=%s, affected_citizens=%s WHERE id=%s", (r["n"], r["u"], pid))


def recompute_priority(pid):
    """Priority score for a primary complaint; same score copied to its linked duplicates."""
    c = db.query("SELECT * FROM complaints WHERE id=%s", (pid,), one=True)
    if not c:
        return None
    rows = db.query(
        "SELECT a.severity, a.risk FROM ai_analysis a JOIN complaints x ON x.id=a.complaint_id "
        "WHERE x.id=%s OR x.primary_id=%s", (pid, pid))
    sev = risk = None
    if rows:
        sev = max((r["severity"] for r in rows), key=priority_service.level_rank)
        risk = max((r["risk"] for r in rows), key=priority_service.level_rank)
    score, level = priority_service.compute(sev, risk, c["affected_citizens"], c["location_type"], c["created_at"])
    db.execute("UPDATE complaints SET priority_score=%s, priority_level=%s WHERE id=%s OR primary_id=%s",
               (score, level, pid, pid))
    return score, level


def link_or_prioritise(cid):
    cfg = current_app.config
    c = db.query("SELECT * FROM complaints WHERE id=%s", (cid,), one=True)
    match = duplicate_service.find_primary(c, cfg["DUPLICATE_RADIUS_M"], cfg["DUPLICATE_SIMILARITY"])
    if match:
        pid = match[0]
        db.execute("UPDATE complaints SET primary_id=%s WHERE id=%s", (pid, cid))
        refresh_group_counts(pid)
        score, level = recompute_priority(pid)
        p = db.query("SELECT status FROM complaints WHERE id=%s", (pid,), one=True)
        db.execute("UPDATE complaints SET status=%s WHERE id=%s", (p["status"], cid))
        notify(c["user_id"], cid,
               f"Your report #{cid} matches an existing report #{pid} at the same spot and is linked to it "
               f"(priority {level}). You will get updates as work progresses.")
    else:
        score, level = recompute_priority(cid)
        notify(c["user_id"], cid, f"Your report #{cid} '{c['title']}' was received. Priority: {level} ({score}/100).")


def refresh_open_priorities():
    """Waiting days maaruvadhaala, admin dashboard open aagum pothu scores refresh aagum."""
    for r in db.query("SELECT id FROM complaints WHERE primary_id IS NULL AND status<>'Resolved'"):
        recompute_priority(r["id"])


def set_group_status(pid, status):
    db.execute("UPDATE complaints SET status=%s WHERE id=%s OR primary_id=%s", (status, pid, pid))
