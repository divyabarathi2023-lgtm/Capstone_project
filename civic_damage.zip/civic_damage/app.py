import os

from flask import Flask, abort, flash, g, redirect, render_template, request, send_from_directory, session, url_for
from flask_wtf.csrf import CSRFError, CSRFProtect

import db
from auth_utils import home_for, login_required
from config import Config


def create_app(config_overrides=None):
    app = Flask(__name__)
    app.config.from_object(Config)
    if config_overrides:
        app.config.update(config_overrides)
    os.makedirs(app.config["UPLOAD_FOLDER"], exist_ok=True)

    CSRFProtect(app)
    app.teardown_appcontext(db.close_db)

    import routes_admin, routes_auth, routes_citizen, routes_worker
    for m in (routes_auth, routes_citizen, routes_admin, routes_worker):
        app.register_blueprint(m.bp)

    @app.before_request
    def load_user():
        g.user = None
        uid = session.get("user_id")
        if uid:
            g.user = db.query("SELECT id,name,email,role FROM users WHERE id=%s", (uid,), one=True)
            if not g.user:
                session.clear()

    @app.context_processor
    def inject_globals():
        unread = 0
        if g.get("user"):
            unread = db.query("SELECT COUNT(*) AS n FROM notifications WHERE user_id=%s AND is_read=0",
                              (g.user["id"],), one=True)["n"]
        return {"unread_count": unread}

    @app.route("/")
    def index():
        if g.user:
            return redirect(home_for(g.user["role"]))
        return redirect(url_for("auth.login"))

    @app.route("/uploads/<path:filename>")
    @login_required()
    def uploads(filename):
        return send_from_directory(app.config["UPLOAD_FOLDER"], filename)

    @app.errorhandler(413)
    def too_large(e):
        flash("Upload too large. Maximum image size is 8 MB.", "danger")
        return redirect(request.referrer or url_for("index"))

    @app.errorhandler(CSRFError)
    def csrf_error(e):
        flash("Session expired. Please try again.", "warning")
        return redirect(request.referrer or url_for("index"))

    @app.errorhandler(403)
    def forbidden(e):
        return render_template("error.html", code=403, msg="You do not have access to this page."), 403

    @app.errorhandler(404)
    def not_found(e):
        return render_template("error.html", code=404, msg="Page not found."), 404

    return app


app = create_app()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
