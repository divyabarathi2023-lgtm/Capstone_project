import os

BASE_DIR = os.path.abspath(os.path.dirname(__file__))


class Config:
    SECRET_KEY = os.environ.get("SECRET_KEY", "change-this-to-a-long-random-string")

    # ---------------- MySQL (unga MySQL details inga fill pannunga) ----------------
    DB_HOST = os.environ.get("DB_HOST", "localhost")
    DB_PORT = int(os.environ.get("DB_PORT", "3306"))
    DB_USER = os.environ.get("DB_USER", "root")
    DB_PASSWORD = os.environ.get("DB_PASSWORD", "")          # <-- FILL: MySQL password
    DB_NAME = os.environ.get("DB_NAME", "civic_damage")

    # ---------------- Nexus API (doc vandha apuram fill pannunga) ----------------
    NEXUS_API_KEY = os.environ.get("NEXUS_API_KEY", "PASTE_YOUR_NEXUS_API_KEY_HERE")   # <-- FILL
    NEXUS_API_URL = os.environ.get("NEXUS_API_URL", "PASTE_NEXUS_API_URL_HERE")        # <-- FILL
    NEXUS_MODEL = os.environ.get("NEXUS_MODEL", "")                                    # <-- FILL (doc-la model name irundha)
    NEXUS_TIMEOUT = 60

    # ---------------- Upload rules ----------------
    UPLOAD_FOLDER = os.path.join(BASE_DIR, "uploads")
    MAX_IMAGE_BYTES = 8 * 1024 * 1024            # 8 MB per image
    MAX_CONTENT_LENGTH = 9 * 1024 * 1024         # whole request limit

    # ---------------- Duplicate detection ----------------
    DUPLICATE_RADIUS_M = 50
    DUPLICATE_SIMILARITY = 0.70

    # Seed accounts (init_db.py use pannum)
    ADMIN_EMAIL = "admin@example.com"
    ADMIN_PASSWORD = "Admin@123"
    WORKER_EMAIL = "worker@example.com"
    WORKER_PASSWORD = "Worker@123"
