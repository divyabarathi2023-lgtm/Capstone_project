import re
from datetime import datetime

from flask import Blueprint, abort, flash, g, redirect, render_template, request, url_for
from werkzeug.security import generate_password_hash

import db
from auth_utils import login_required
from services import complaint_service as cs
from services.notification_service import notify, notify_group

bp = Blueprint("admin", __name__, url_prefix="/admin")
LEVELS = ["Critical", "High", "Medium", "Low"]
STATUSES = ["Submitted", "Assigned", "In Progress", "Completed", "Resolved"]


def _primary_or_404(cid):
    c = db.query("SELECT * FROM complaints WHERE id=%s", (cid,), one=True)
    if not c:
        abort(404)
    return c


@bp.route("/")
@login_required("admin")
def dashboard():
    cs.refresh_open_priorities()
    f_status = request.args.get("status", "")
    f_level = request.args.get("level", "")
    where, args = ["c.primary_id IS NULL"], []
    if f_status in STATUSES:
        where.append("c.status=%s")
        args.append(f_status)
    if f_level in LEVELS:
        where.append("c.priority_level=%s")
        args.append(f_level)
    rows = db.query(
        "SELECT c.*, w.name AS worker_name FROM complaints c LEFT JOIN users w ON w.id=c.assigned_worker_id "
        "WHERE " + " AND ".join(where) +
        " ORDER BY c.priority_score DESC, c.created_at ASC", args)

    allp = db.query("SELECT status, priority_level, category, latitude, longitude, id, title, priority_score "
                    "FROM complaints WHERE primary_id IS NULL")
    by_status = {s: 0 for s in STATUSES}
    by_level = {l: 0 for l in LEVELS}
    by_cat = {}
    for r in allp:
        by_status[r["status"]] += 1
        by_level[r["priority_level"]] = by_level.get(r["priority_level"], 0) + 1
        by_cat[r["category"]] = by_cat.get(r["category"], 0) + 1
    markers = [{"id": r["id"], "title": r["title"], "lat": r["latitude"], "lng": r["longitude"],
                "level": r["priority_level"], "score": r["priority_score"], "status": r["status"]}
               for r in allp if r["status"] != "Resolved"]
    dups = db.query("SELECT COUNT(*) AS n FROM complaints WHERE primary_id IS NOT NULL", one=True)["n"]
    return render_template("admin/dashboard.html", rows=rows, by_status=by_status, by_level=by_level,
                           by_cat=by_cat, markers=markers, total=len(allp), dups=dups,
                           statuses=STATUSES, levels=LEVELS, f_status=f_status, f_level=f_level)


@bp.route("/complaint/<int:cid>")
@login_required("admin")
def complaint(cid):
    c = _primary_or_404(cid)
    if c["primary_id"]:
        return redirect(url_for("admin.complaint", cid=c["primary_id"]))
    ai = db.query("SELECT * FROM ai_analysis WHERE complaint_id=%s ORDER BY id DESC", (cid,), one=True)
    group = db.query("SELECT c.*, u.name AS reporter FROM complaints c JOIN users u ON u.id=c.user_id "
                     "WHERE c.id=%s OR c.primary_id=%s ORDER BY c.created_at", (cid, cid))
    workers = db.query("SELECT id, name FROM users WHERE role='worker' ORDER BY name")
    worker = db.query("SELECT name FROM users WHERE id=%s", (c["assigned_worker_id"],), one=True) \
        if c["assigned_worker_id"] else None
    return render_template("admin/complaint.html", c=c, ai=ai, group=group, workers=workers, worker=worker)


@bp.route("/complaint/<int:cid>/assign", methods=["POST"])
@login_required("admin")
def assign(cid):
    c = _primary_or_404(cid)
    if c["primary_id"] or c["status"] not in ("Submitted", "Assigned"):
        flash("This complaint cannot be (re)assigned now.", "danger")
        return redirect(url_for("admin.complaint", cid=cid))
    try:
        wid = int(request.form.get("worker_id", ""))
    except ValueError:
        wid = 0
    w = db.query("SELECT id, name FROM users WHERE id=%s AND role='worker'", (wid,), one=True)
    if not w:
        flash("Please choose a worker.", "danger")
        return redirect(url_for("admin.complaint", cid=cid))
    note = request.form.get("admin_note", "").strip()[:2000] or None
    db.execute("UPDATE complaints SET assigned_worker_id=%s, assigned_at=%s, admin_note=%s WHERE id=%s",
               (wid, datetime.now(), note, cid))
    cs.set_group_status(cid, "Assigned")
    notify(wid, cid, f"New complaint #{cid} '{c['title']}' has been assigned to you.")
    notify_group(cid, f"Your report #{cid} '{c['title']}' has been assigned to a repair worker.")
    flash(f"Assigned to {w['name']}.", "success")
    return redirect(url_for("admin.complaint", cid=cid))


@bp.route("/complaint/<int:cid>/resolve", methods=["POST"])
@login_required("admin")
def resolve(cid):
    c = _primary_or_404(cid)
    if c["primary_id"] or c["status"] != "Completed":
        flash("Only complaints marked Completed by a worker can be resolved.", "danger")
        return redirect(url_for("admin.complaint", cid=cid))
    cs.set_group_status(cid, "Resolved")
    db.execute("UPDATE complaints SET resolved_at=%s WHERE id=%s OR primary_id=%s", (datetime.now(), cid, cid))
    notify_group(cid, f"Good news! Your report '{c['title']}' (#{cid}) has been Resolved. Thank you for reporting.")
    flash("Complaint marked Resolved. Citizens notified.", "success")
    return redirect(url_for("admin.complaint", cid=cid))


@bp.route("/complaint/<int:cid>/rerun-ai", methods=["POST"])
@login_required("admin")
def rerun_ai(cid):
    c = _primary_or_404(cid)
    status, msg = cs.run_ai(cid)
    cs.recompute_priority(c["primary_id"] or cid)
    flash("AI analysis completed." if status == "done" else f"AI analysis {status}: {msg}",
          "success" if status == "done" else "warning")
    return redirect(url_for("admin.complaint", cid=c["primary_id"] or cid))


@bp.route("/duplicates")
@login_required("admin")
def duplicates():
    prim = db.query("SELECT * FROM complaints WHERE primary_id IS NULL AND report_count>1 "
                    "ORDER BY report_count DESC, priority_score DESC")
    groups = []
    for p in prim:
        kids = db.query("SELECT c.*, u.name AS reporter FROM complaints c JOIN users u ON u.id=c.user_id "
                        "WHERE c.primary_id=%s ORDER BY c.created_at", (p["id"],))
        groups.append({"primary": p, "kids": kids})
    return render_template("admin/duplicates.html", groups=groups)


@bp.route("/workers", methods=["GET", "POST"])
@login_required("admin")
def workers():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip().lower()
        pwd = request.form.get("password", "")
        if len(name) < 2 or not re.match(r"^[^@\s]+@[^@\s]+\.[^@\s]+$", email) or len(pwd) < 6:
            flash("Enter name, valid email and a password of 6+ characters.", "danger")
        elif db.query("SELECT id FROM users WHERE email=%s", (email,), one=True):
            flash("Email already exists.", "danger")
        else:
            db.execute("INSERT INTO users (name,email,password_hash,role,created_at) VALUES (%s,%s,%s,'worker',%s)",
                       (name, email, generate_password_hash(pwd), datetime.now()))
            flash("Worker account created.", "success")
        return redirect(url_for("admin.workers"))
    rows = db.query("SELECT w.id, w.name, w.email, "
                    "(SELECT COUNT(*) FROM complaints c WHERE c.assigned_worker_id=w.id AND c.status IN ('Assigned','In Progress')) AS active "
                    "FROM users w WHERE w.role='worker' ORDER BY w.name")
    return render_template("admin/workers.html", workers=rows)
