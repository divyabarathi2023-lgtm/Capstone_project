"""Run once:  python init_db.py   -> database, tables, admin & worker accounts create aagum."""
import os
import pymysql
from datetime import datetime
from werkzeug.security import generate_password_hash
from config import Config as C

conn = pymysql.connect(host=C.DB_HOST, port=C.DB_PORT, user=C.DB_USER, password=C.DB_PASSWORD,
                       charset="utf8mb4", autocommit=True)
cur = conn.cursor()
cur.execute(f"CREATE DATABASE IF NOT EXISTS `{C.DB_NAME}` CHARACTER SET utf8mb4")
cur.execute(f"USE `{C.DB_NAME}`")

with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "schema.sql"), encoding="utf-8") as f:
    for stmt in f.read().split(";"):
        if stmt.strip():
            cur.execute(stmt)

seeds = [
    ("Admin", C.ADMIN_EMAIL, C.ADMIN_PASSWORD, "admin"),
    ("Worker One", C.WORKER_EMAIL, C.WORKER_PASSWORD, "worker"),
]
for name, email, pwd, role in seeds:
    cur.execute("SELECT id FROM users WHERE email=%s", (email,))
    if not cur.fetchone():
        cur.execute(
            "INSERT INTO users (name,email,password_hash,role,created_at) VALUES (%s,%s,%s,%s,%s)",
            (name, email, generate_password_hash(pwd), role, datetime.now()),
        )
        print(f"Created {role}: {email} / {pwd}")
    else:
        print(f"{role} already exists: {email}")
cur.close()
conn.close()
os.makedirs(C.UPLOAD_FOLDER, exist_ok=True)
print("Database ready.")
