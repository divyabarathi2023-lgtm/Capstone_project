import os
from datetime import datetime

from flask import Blueprint, abort, current_app, flash, g, redirect, render_template, request, url_for

import db
from auth_utils import login_required
from services import complaint_service as cs
from services import image_service
from services.notification_service import notify_group

bp = Blueprint("worker", __name__, url_prefix="/worker")


def _mine_or_404(cid):
    c = db.query("SELECT * FROM complaints WHERE id=%s AND primary_id IS NULL AND assigned_worker_id=%s",
                 (cid, g.user["id"]), one=True)
    if not c:
        abort(404)
    return c


@bp.route("/")
@login_required("worker")
def dashboard():
    rows = db.query("SELECT * FROM complaints WHERE assigned_worker_id=%s AND primary_id IS NULL "
                    "ORDER BY FIELD(status,'In Progress','Assigned','Completed','Resolved'), priority_score DESC",
                    (g.user["id"],))
    return render_template("worker/dashboard.html", complaints=rows)


@bp.route("/complaint/<int:cid>")
@login_required("worker")
def complaint(cid):
    c = _mine_or_404(cid)
    ai = db.query("SELECT * FROM ai_analysis WHERE complaint_id=%s ORDER BY id DESC", (cid,), one=True)
    return render_template("worker/complaint.html", c=c, ai=ai)


@bp.route("/complaint/<int:cid>/update", methods=["POST"])
@login_required("worker")
def update(cid):
    c = _mine_or_404(cid)
    new = request.form.get("status", "")
    note = request.form.get("worker_note", "").strip()[:2000] or None
    allowed = {"Assigned": ["In Progress"], "In Progress": ["Completed"]}
    if new not in allowed.get(c["status"], []):
        flash(f"You cannot change status from '{c['status']}' to '{new}'.", "danger")
        return redirect(url_for("worker.complaint", cid=cid))

    if new == "Completed":
        try:
            fname, _img, _m = image_service.validate_and_save(
                request.files.get("completion_photo"), current_app.config["UPLOAD_FOLDER"],
                current_app.config["MAX_IMAGE_BYTES"], "completion")
        except ValueError as e:
            flash(f"Completion photo required: {e}", "danger")
            return redirect(url_for("worker.complaint", cid=cid))
        db.execute("UPDATE complaints SET completion_photo=%s, completed_at=%s, worker_note=%s WHERE id=%s",
                   (fname, datetime.now(), note, cid))
        cs.set_group_status(cid, "Completed")
        notify_group(cid, f"Repair work for your report '{c['title']}' (#{cid}) is completed. Awaiting final verification.")
    else:
        db.execute("UPDATE complaints SET worker_note=%s WHERE id=%s", (note, cid))
        cs.set_group_status(cid, "In Progress")
        notify_group(cid, f"Repair work has started for your report '{c['title']}' (#{cid}).")
    flash(f"Status updated to {new}.", "success")
    return redirect(url_for("worker.complaint", cid=cid))
