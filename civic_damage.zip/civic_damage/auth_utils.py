from functools import wraps
from flask import g, flash, redirect, url_for


def home_for(role):
    return url_for({"admin": "admin.dashboard", "worker": "worker.dashboard"}.get(role, "citizen.dashboard"))


def login_required(*roles):
    """Use as @login_required() or @login_required('admin')."""
    def deco(f):
        @wraps(f)
        def wrapper(*args, **kwargs):
            if not g.get("user"):
                flash("Please login first.", "warning")
                return redirect(url_for("auth.login"))
            if roles and g.user["role"] not in roles:
                flash("You are not allowed to open that page.", "danger")
                return redirect(home_for(g.user["role"]))
            return f(*args, **kwargs)
        return wrapper
    return deco
