from flask import Blueprint, abort, flash, g, redirect, render_template, request, url_for

import db
from auth_utils import login_required
from services import complaint_service as cs

bp = Blueprint("citizen", __name__)


@bp.route("/dashboard")
@login_required("citizen")
def dashboard():
    rows = db.query("SELECT * FROM complaints WHERE user_id=%s ORDER BY created_at DESC", (g.user["id"],))
    return render_template("citizen_dashboard.html", complaints=rows)


@bp.route("/report", methods=["GET", "POST"])
@login_required("citizen")
def report():
    if request.method == "POST":
        try:
            cid = cs.create_complaint(g.user, request.form, request.files.get("photo"))
            flash("Report submitted successfully.", "success")
            return redirect(url_for("citizen.detail", cid=cid))
        except ValueError as e:
            flash(str(e), "danger")
    return render_template("report.html", categories=cs.CATEGORIES, location_types=cs.LOCATION_TYPES,
                           form=request.form)


@bp.route("/complaint/<int:cid>")
@login_required("citizen", "admin", "worker")
def detail(cid):
    c = db.query("SELECT c.*, u.name AS reporter FROM complaints c JOIN users u ON u.id=c.user_id WHERE c.id=%s",
                 (cid,), one=True)
    if not c:
        abort(404)
    role = g.user["role"]
    pid = c["primary_id"] or c["id"]
    if role == "citizen" and c["user_id"] != g.user["id"]:
        abort(403)
    if role == "worker":
        p = db.query("SELECT assigned_worker_id FROM complaints WHERE id=%s", (pid,), one=True)
        if p["assigned_worker_id"] != g.user["id"]:
            abort(403)
    primary = c if not c["primary_id"] else db.query("SELECT * FROM complaints WHERE id=%s", (pid,), one=True)
    ai = db.query("SELECT * FROM ai_analysis WHERE complaint_id=%s ORDER BY id DESC", (cid,), one=True)
    if not ai and c["primary_id"]:
        ai = db.query("SELECT * FROM ai_analysis WHERE complaint_id=%s ORDER BY id DESC", (pid,), one=True)
    return render_template("complaint_detail.html", c=c, primary=primary, ai=ai)


@bp.route("/notifications")
@login_required()
def notifications():
    rows = db.query("SELECT * FROM notifications WHERE user_id=%s ORDER BY created_at DESC, id DESC LIMIT 100",
                    (g.user["id"],))
    db.execute("UPDATE notifications SET is_read=1 WHERE user_id=%s AND is_read=0", (g.user["id"],))
    return render_template("notifications.html", notes=rows)
