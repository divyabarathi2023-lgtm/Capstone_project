# Civic Damage Reporter (Flask + MySQL + OpenCV + Nexus AI)

Flow: Citizen report → AI analysis → duplicate check → priority score → admin assign → worker repair → citizen notification.

## 1. Setup
```bash
python -m venv venv
venv\Scripts\activate          # Windows   (Linux/Mac: source venv/bin/activate)
pip install -r requirements.txt
```

## 2. Fill these in `config.py`
| Setting | What to put |
|---|---|
| `DB_PASSWORD` | your MySQL root password |
| `DB_USER`, `DB_HOST`, `DB_NAME` | change only if different |
| `NEXUS_API_KEY` | `PASTE_YOUR_NEXUS_API_KEY_HERE` → your Nexus key |
| `NEXUS_API_URL` | `PASTE_NEXUS_API_URL_HERE` → Nexus endpoint URL |
| `NEXUS_MODEL` | model name if the Nexus doc asks for one |
| `SECRET_KEY` | any long random string |

(You can also use environment variables with the same names.)

## 3. Create database + demo accounts, then run
```bash
python init_db.py      # creates DB, tables, admin & worker
python app.py          # open http://127.0.0.1:5000
```
Demo logins: `admin@example.com / Admin@123`, `worker@example.com / Worker@123`.
Citizens register themselves. Admin can add more workers (Workers page).

## 4. Nexus API
All Nexus code is in `services/ai_service.py`.
* Until the key is filled, the app runs normally: AI status = `skipped`, priority uses "medium" defaults.
* When the Nexus doc arrives, only edit `build_request()` (headers/body) if its format differs.
  The response parser searches for the JSON with `damage_type, severity, risk, confidence, description, repair_action`
  anywhere in the response, so it usually needs no change.
* Admin can press **Run AI analysis again** on any complaint whose AI status is not `done`.

## 5. Rules implemented
* Image: JPG/PNG/WEBP, real-image check, 8 MB max. OpenCV pHash + HSV colour histogram stored.
* Duplicate: same category, ≤ 50 m, similarity ≥ 0.70 (50% pHash + 50% histogram) with an open primary complaint.
  Reports are never deleted; `report_count` and `affected_citizens` update. (Tune in `config.py`.)
* Priority (0-100): severity 30 + safety risk 25 + affected citizens 20 + location importance 15 + waiting days 10.
  Critical ≥ 80, High ≥ 60, Medium ≥ 40, else Low.
* Status: Submitted → Assigned → In Progress → Completed (worker, completion photo needed) → Resolved (admin verifies).
  Every citizen linked to the damage gets notified at each step.

## Notes
* Browser GPS works on `localhost` or HTTPS only. On plain HTTP (e.g. phone over Wi-Fi) the user can type lat/lng.
* Admin map/charts load Leaflet and Chart.js from CDN, so internet is needed in the browser.
* For production, run with gunicorn/waitress, set `debug=False` and a strong `SECRET_KEY`.
